# NEXUS Agent Instructions

These rules apply to later coding/review agents, including Gemini and Codex.

- Read `GEMINI.md` and the relevant `docs/specs/` files before major changes.
- Treat `docs/design/NEXUS_FINAL_UI_REFERENCE.png` as approved visual direction and `docs/design/REFERENCE_NOTES.md` as the browser-reality correction layer.
- Preserve local-first privacy, stable project/node identity, compact persistence, and graph-engine/rendering separation.
- Do not introduce mobile, backend requirements, accounts, collaboration, cloud source storage, or AI into V1 unless the product owner explicitly changes scope.
- Do not upload, proxy, or persist raw source code to a remote backend by default.
- Prefer inspectable deterministic analysis over black-box heuristics.
- Never preserve an inert control just because it exists in the scaffold/reference.
- Never claim validation the current environment cannot perform.
- At minimum, require a clean local test run and production build before declaring implementation work complete; perform browser/manual validation later when an environment actually supports it.
- Review behavior against `docs/specs/ACCEPTANCE_TESTS.md`, while clearly separating automated checks from still-unverified browser-only checks.
